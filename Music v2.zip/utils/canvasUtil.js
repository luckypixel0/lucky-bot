const { createCanvas } = require('canvas');

function createTextCanvas(text, width = 400, height = 100, bgColor = '#0099ff', textColor = '#ffffff') {
  const canvas = createCanvas(width, height);
  const context = canvas.getContext('2d');

  // Background
  context.fillStyle = bgColor;
  context.fillRect(0, 0, width, height);

  // Text
  context.font = '40px sans-serif';
  context.fillStyle = textColor;
  context.fillText(text, 20, height / 2 + 15);

  return canvas;
}

module.exports = {
  createTextCanvas
};
