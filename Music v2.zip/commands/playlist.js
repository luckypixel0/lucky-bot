const { SlashCommandBuilder } = require('discord.js');
const { createCanvas, loadImage } = require('canvas');
const fs = require('fs');
const path = require('path');

// Path to the playlists directory
const PLAYLISTS_DIR = path.join(__dirname, '../playlists');

// Ensure playlists directory exists
if (!fs.existsSync(PLAYLISTS_DIR)) {
  fs.mkdirSync(PLAYLISTS_DIR, { recursive: true });
}

/**
 * Get all available playlist names
 * @returns {Array<{name: string, value: string}>} Array of playlist names
 */
function getAvailablePlaylists() {
  try {
    if (!fs.existsSync(PLAYLISTS_DIR)) return [];
    
    const files = fs.readdirSync(PLAYLISTS_DIR).filter(file => file.endsWith('.json'));
    return files.map(file => {
      try {
        const data = JSON.parse(fs.readFileSync(path.join(PLAYLISTS_DIR, file), 'utf8'));
        const name = data.name || path.basename(file, '.json');
        const trackCount = data.tracks?.length || 0;
        
        return { 
          name: `${name} (${trackCount} tracks)`, 
          value: name 
        };
      } catch (err) {
        // Handle corrupted playlist files
        return { 
          name: path.basename(file, '.json'), 
          value: path.basename(file, '.json') 
        };
      }
    });
  } catch (error) {
    console.error("Error getting available playlists:", error);
    return [];
  }
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('playlist')
    .setDescription('Manage and play music playlists')
    
    // Create subcommand
    .addSubcommand(subcommand =>
      subcommand
        .setName('create')
        .setDescription('Create a new playlist')
        .addStringOption(option =>
          option.setName('name')
            .setDescription('Name of the playlist')
            .setRequired(true)))
    
    // Add track subcommand
    .addSubcommand(subcommand =>
      subcommand
        .setName('add')
        .setDescription('Add current track to a playlist')
        .addStringOption(option =>
          option.setName('name')
            .setDescription('Name of the playlist')
            .setAutocomplete(true)
            .setRequired(true)))
    
    // Remove track subcommand
    .addSubcommand(subcommand =>
      subcommand
        .setName('remove')
        .setDescription('Remove a track from a playlist')
        .addStringOption(option =>
          option.setName('name')
            .setDescription('Name of the playlist')
            .setAutocomplete(true)
            .setRequired(true))
        .addIntegerOption(option =>
          option.setName('position')
            .setDescription('Position of the track to remove (starts at 1)')
            .setRequired(true)
            .setMinValue(1)))
    
    // List playlists subcommand
    .addSubcommand(subcommand =>
      subcommand
        .setName('list')
        .setDescription('List all available playlists'))
    
    // View playlist subcommand
    .addSubcommand(subcommand =>
      subcommand
        .setName('view')
        .setDescription('View tracks in a playlist')
        .addStringOption(option =>
          option.setName('name')
            .setDescription('Name of the playlist')
            .setAutocomplete(true)
            .setRequired(true)))

    // Play playlist subcommand
    .addSubcommand(subcommand =>
      subcommand
        .setName('play')
        .setDescription('Play a playlist')
        .addStringOption(option =>
          option.setName('name')
            .setDescription('Name of the playlist')
            .setAutocomplete(true)
            .setRequired(true)))
            
    // Delete playlist subcommand
    .addSubcommand(subcommand =>
      subcommand
        .setName('delete')
        .setDescription('Delete an entire playlist')
        .addStringOption(option =>
          option.setName('name')
            .setDescription('Name of the playlist to delete')
            .setAutocomplete(true)
            .setRequired(true))),

  async autocomplete(interaction) {
    const focusedOption = interaction.options.getFocused(true);
    
    if (focusedOption.name === 'name') {
      // Get all available playlists
      const playlistsDir = path.join(__dirname, '../playlists');
      const playlists = [];
      
      try {
        if (fs.existsSync(playlistsDir)) {
          const files = fs.readdirSync(playlistsDir).filter(file => file.endsWith('.json'));
          
          for (const file of files) {
            try {
              const data = JSON.parse(fs.readFileSync(path.join(playlistsDir, file), 'utf8'));
              const name = data.name || path.basename(file, '.json');
              const trackCount = data.tracks && Array.isArray(data.tracks) ? data.tracks.length : 0;
              
              playlists.push({ 
                name: `${name} (${trackCount} tracks)`,
                value: name 
              });
            } catch (err) {
              // Handle corrupted playlist files
              const name = path.basename(file, '.json');
              playlists.push({ 
                name: name,
                value: name
              });
            }
          }
        }
      } catch (error) {
        console.error("Error getting playlists for autocomplete:", error);
      }
      
      // Filter based on user input
      const filtered = playlists.filter(playlist => 
        playlist.value.toLowerCase().includes(focusedOption.value.toLowerCase())
      );
      
      // Return the filtered results (max 25)
      await interaction.respond(filtered.slice(0, 25));
    }
  },

  async execute(interaction, client) {
    const subcommand = interaction.options.getSubcommand();
    const playlistsDir = path.join(__dirname, '../playlists');
    
    switch (subcommand) {
      case 'create':
        await handleCreate(interaction);
        break;
      case 'add':
        await handleAdd(interaction, client);
        break;
      case 'remove':
        await handleRemove(interaction);
        break;
      case 'list':
        await handleList(interaction);
        break;
      case 'view':
        await handleView(interaction);
        break;
      case 'play':
        await handlePlay(interaction, client);
        break;
      case 'delete':
        await handleDelete(interaction);
        break;
    }
  }
};

/**
 * Handle the create subcommand
 */
async function handleCreate(interaction) {
  const name = interaction.options.getString('name');
  const sanitizedName = sanitizeFilename(name);
  const filePath = path.join(PLAYLISTS_DIR, `${sanitizedName}.json`);
  
  if (fs.existsSync(filePath)) {
    return interaction.reply({ 
      content: `❌ A playlist named "${name}" already exists.`,
      ephemeral: true 
    });
  }
  
  try {
    fs.writeFileSync(filePath, JSON.stringify({ name, tracks: [] }, null, 2));
    await interaction.reply(`✅ Created playlist: **${name}**`);
  } catch (error) {
    console.error(error);
    await interaction.reply({ 
      content: 'There was an error creating the playlist.',
      ephemeral: true 
    });
  }
}

/**
 * Handle the add subcommand
 */
async function handleAdd(interaction, client) {
  const player = client.riffy.players.get(interaction.guildId);
  
  if (!player || !player.current) {
    return interaction.reply({ 
      content: 'There is no track playing right now.',
      ephemeral: true 
    });
  }
  
  const name = interaction.options.getString('name');
  const sanitizedName = sanitizeFilename(name);
  const filePath = path.join(PLAYLISTS_DIR, `${sanitizedName}.json`);
  
  if (!fs.existsSync(filePath)) {
    return interaction.reply({ 
      content: `❌ Playlist "${name}" doesn't exist. Create it first with /playlist create`,
      ephemeral: true
    });
  }
  
  try {
    const playlist = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    const currentTrack = {
      title: player.current.title || 'Unknown Title',
      url: player.current.url,
      author: player.current.author || 'Unknown Artist',
      duration: player.current.duration,
      thumbnail: player.current.thumbnail
    };

    // Ensure title is never "undefined" string
    if (currentTrack.title === 'undefined') {
      currentTrack.title = 'Unknown Title';
    }
    
    // Check if track already exists in playlist
    const exists = playlist.tracks.some(track => track.url === currentTrack.url);
    if (exists) {
      return interaction.reply({ 
        content: `❌ This track is already in playlist **${name}**`,
        ephemeral: true 
      });
    }
    
    playlist.tracks.push(currentTrack);
    fs.writeFileSync(filePath, JSON.stringify(playlist, null, 2));
    
    const trackTitle = currentTrack.title || 'Unknown track';
    await interaction.reply(`✅ Added **${trackTitle}** to playlist **${name}**`);
  } catch (error) {
    console.error(error);
    await interaction.reply({ 
      content: 'There was an error adding the track to the playlist.',
      ephemeral: true 
    });
  }
}

/**
 * Handle the remove subcommand
 */
async function handleRemove(interaction) {
  const name = interaction.options.getString('name');
  const position = interaction.options.getInteger('position');
  const sanitizedName = sanitizeFilename(name);
  const filePath = path.join(PLAYLISTS_DIR, `${sanitizedName}.json`);
  
  if (!fs.existsSync(filePath)) {
    return interaction.reply({ 
      content: `❌ Playlist "${name}" doesn't exist.`,
      ephemeral: true
    });
  }
  
  try {
    const playlist = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    
    if (position > playlist.tracks.length) {
      return interaction.reply({ 
        content: `❌ Invalid position. The playlist only has ${playlist.tracks.length} tracks.`,
        ephemeral: true 
      });
    }
    
    const removedTrack = playlist.tracks.splice(position - 1, 1)[0];
    fs.writeFileSync(filePath, JSON.stringify(playlist, null, 2));
    
    const trackTitle = removedTrack.title || 'Unknown track';
    await interaction.reply(`✅ Removed **${trackTitle}** from playlist **${name}**`);
  } catch (error) {
    console.error(error);
    await interaction.reply({ 
      content: 'There was an error removing the track from the playlist.',
      ephemeral: true 
    });
  }
}

/**
 * Handle the list subcommand
 */
async function handleList(interaction) {
  await interaction.deferReply();
  
  try {
    const files = fs.readdirSync(PLAYLISTS_DIR).filter(file => file.endsWith('.json'));
    
    if (files.length === 0) {
      return interaction.editReply('No playlists found. Create one with `/playlist create`');
    }
    
    const playlists = files.map(file => {
      try {
        const data = JSON.parse(fs.readFileSync(path.join(PLAYLISTS_DIR, file), 'utf8'));
        return {
          name: data.name || path.basename(file, '.json'),
          trackCount: data.tracks ? data.tracks.length : 0
        };
      } catch (err) {
        // Handle corrupted playlist files
        return {
          name: path.basename(file, '.json'),
          trackCount: 0
        };
      }
    });
    
    // Create canvas
    const canvas = createCanvas(600, 100 + playlists.length * 50);
    const ctx = canvas.getContext('2d');
    
    // Background with gradient
    const bgGradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    bgGradient.addColorStop(0, '#1a1b1e');
    bgGradient.addColorStop(1, '#292b2f');
    ctx.fillStyle = bgGradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add glass-like effect to the background
    // Subtle diagonal lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.lineWidth = 1;
    for (let i = -canvas.height; i < canvas.width; i += 15) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i + canvas.height, canvas.height);
      ctx.stroke();
    }
    
    // Add subtle noise texture
    for (let i = 0; i < 800; i++) {
      const x = Math.random() * canvas.width;
      const y = Math.random() * canvas.height;
      const opacity = Math.random() * 0.03;
      
      ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`;
      ctx.fillRect(x, y, 1, 1);
    }
    
    // Glass header effect
    const headerGradient = ctx.createLinearGradient(0, 0, 0, 60);
    headerGradient.addColorStop(0, 'rgba(88, 101, 242, 0.8)');
    headerGradient.addColorStop(1, 'rgba(88, 101, 242, 0.6)');
    ctx.fillStyle = headerGradient;
    
    // Rounded header
    const headerHeight = 60;
    const radius = 15;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(canvas.width, 0);
    ctx.lineTo(canvas.width, headerHeight - radius);
    ctx.arcTo(canvas.width, headerHeight, canvas.width - radius, headerHeight, radius);
    ctx.lineTo(radius, headerHeight);
    ctx.arcTo(0, headerHeight, 0, headerHeight - radius, radius);
    ctx.closePath();
    ctx.fill();
    
    // Header highlight to enhance glass effect
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 2);
    ctx.lineTo(canvas.width, 2);
    ctx.stroke();
    
    // Header text with shadow
    ctx.shadowColor = 'rgba(0, 0, 0, 0.4)';
    ctx.shadowBlur = 10;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 3;
    ctx.font = 'bold 28px sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(`Available Playlists (${playlists.length})`, 20, 40);
    
    // Reset shadow
    ctx.shadowColor = 'transparent';
    ctx.shadowBlur = 0;
    
    // Playlists
    for (let i = 0; i < playlists.length; i++) {
      const y = 80 + i * 50;
      
      // Alternate row background - glass effect panels
      const rowGradient = ctx.createLinearGradient(0, y - 20, 0, y + 30);
      if (i % 2 === 0) {
        rowGradient.addColorStop(0, 'rgba(54, 57, 63, 0.8)');
        rowGradient.addColorStop(1, 'rgba(54, 57, 63, 0.6)');
      } else {
        rowGradient.addColorStop(0, 'rgba(47, 49, 54, 0.8)');
        rowGradient.addColorStop(1, 'rgba(47, 49, 54, 0.6)');
      }
      
      ctx.fillStyle = rowGradient;
      
      // Rounded rectangle for each row
      const rowRadius = 8;
      ctx.beginPath();
      ctx.moveTo(10, y - 20);
      ctx.lineTo(canvas.width - 10, y - 20);
      ctx.arcTo(canvas.width - 10, y + 30, canvas.width - 10 - rowRadius, y + 30, rowRadius);
      ctx.lineTo(10 + rowRadius, y + 30);
      ctx.arcTo(10, y + 30, 10, y + 30 - rowRadius, rowRadius);
      ctx.closePath();
      ctx.fill();
      
      // Row highlight for glass effect
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(10, y - 19);
      ctx.lineTo(canvas.width - 10, y - 19);
      ctx.stroke();
      
      // Playlist icon - glowing circle
      const iconGradient = ctx.createRadialGradient(30, y, 2, 30, y, 18);
      iconGradient.addColorStop(0, '#8ea1e1');
      iconGradient.addColorStop(0.7, '#5865f2');
      iconGradient.addColorStop(1, '#4752c4');
      
      ctx.fillStyle = iconGradient;
      ctx.beginPath();
      ctx.arc(30, y, 15, 0, Math.PI * 2);
      ctx.fill();
      
      // Icon highlight
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(30, y - 3, 8, 0.8 * Math.PI, 1.8 * Math.PI);
      ctx.stroke();
      
      // Playlist icon symbol
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 16px sans-serif';
      ctx.fillText('♫', 24, y + 5);
      
      // Playlist name with subtle shadow
      ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
      ctx.shadowBlur = 5;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 1;
      ctx.font = 'bold 20px sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(playlists[i].name, 60, y);
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
      
      // Track count
      ctx.font = '16px sans-serif';
      ctx.fillStyle = '#b9bbbe';
      ctx.fillText(`${playlists[i].trackCount} tracks`, 60, y + 20);
      
      // Play button hint - with glass effect
      const buttonGradient = ctx.createLinearGradient(canvas.width - 120, y - 10, canvas.width - 20, y + 10);
      buttonGradient.addColorStop(0, 'rgba(88, 101, 242, 0.2)');
      buttonGradient.addColorStop(1, 'rgba(88, 101, 242, 0.3)');
      
      ctx.fillStyle = buttonGradient;
      // Rounded play button
      ctx.beginPath();
      ctx.roundRect(canvas.width - 120, y - 10, 100, 20, 5);
      ctx.fill();
      
      ctx.font = '14px sans-serif';
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.fillText('/playlist play', canvas.width - 100, y + 5);
    }
    
    const buffer = canvas.toBuffer();
    
    await interaction.editReply({
      content: '📋 **Available Playlists**',
      files: [{ attachment: buffer, name: 'playlists.png' }]
    });
  } catch (error) {
    console.error(error);
    await interaction.editReply({ 
      content: 'There was an error listing the playlists.',
    });
  }
}

/**
 * Handle the view subcommand
 */
async function handleView(interaction) {
  const name = interaction.options.getString('name');
  const sanitizedName = sanitizeFilename(name);
  const filePath = path.join(PLAYLISTS_DIR, `${sanitizedName}.json`);
  
  if (!fs.existsSync(filePath)) {
    return interaction.reply({ 
      content: `❌ Playlist "${name}" doesn't exist.`,
      ephemeral: true
    });
  }
  
  await interaction.deferReply();
  
  try {
    const playlist = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    
    // Check if playlist has tracks property
    if (!playlist.tracks || !Array.isArray(playlist.tracks)) {
      playlist.tracks = []; // Initialize as empty array if missing or not an array
    }
    
    if (playlist.tracks.length === 0) {
      return interaction.editReply(`Playlist **${name}** is empty. Add tracks with \`/playlist add\``);
    }
    
    // Limit to show max 10 tracks
    const displayTracks = playlist.tracks.slice(0, 10);
    const hasMore = playlist.tracks.length > 10;
    
    // Create canvas
    const canvas = createCanvas(800, 120 + displayTracks.length * 60);
    const ctx = canvas.getContext('2d');
    
    // Background with depth gradient
    const bgGradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    bgGradient.addColorStop(0, '#1a1b1e');
    bgGradient.addColorStop(1, '#27292d');
    ctx.fillStyle = bgGradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add glass-like effect to the background
    // Subtle diagonal lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.lineWidth = 1;
    for (let i = -canvas.height; i < canvas.width; i += 15) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i + canvas.height, canvas.height);
      ctx.stroke();
    }
    
    // Add subtle noise texture for glass effect
    for (let i = 0; i < 2000; i++) {
      const x = Math.random() * canvas.width;
      const y = Math.random() * canvas.height;
      const opacity = Math.random() * 0.03;
      
      ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`;
      ctx.fillRect(x, y, 1, 1);
    }
    
    // Header with glass effect
    const headerGradient = ctx.createLinearGradient(0, 0, canvas.width, 70);
    headerGradient.addColorStop(0, 'rgba(88, 101, 242, 0.85)');
    headerGradient.addColorStop(0.5, 'rgba(114, 137, 218, 0.8)');
    headerGradient.addColorStop(1, 'rgba(88, 101, 242, 0.85)');
    ctx.fillStyle = headerGradient;
    
    // Rounded header
    const headerHeight = 70;
    const radius = 15;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(canvas.width, 0);
    ctx.lineTo(canvas.width, headerHeight - radius);
    ctx.arcTo(canvas.width, headerHeight, canvas.width - radius, headerHeight, radius);
    ctx.lineTo(radius, headerHeight);
    ctx.arcTo(0, headerHeight, 0, headerHeight - radius, radius);
    ctx.closePath();
    ctx.fill();
    
    // Add highlights to enhance glass effect
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 2);
    ctx.lineTo(canvas.width, 2);
    ctx.stroke();
    
    // Header text with shadow
    ctx.shadowColor = 'rgba(0, 0, 0, 0.4)';
    ctx.shadowBlur = 10;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 3;
    ctx.font = 'bold 30px sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(`Playlist: ${name}`, 20, 40);
    
    // Track count
    ctx.shadowBlur = 5;
    ctx.font = '16px sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(`${playlist.tracks.length} tracks total`, 25, 60);
    
    // Reset shadow
    ctx.shadowColor = 'transparent';
    ctx.shadowBlur = 0;
    
    // Draw tracks
    for (let i = 0; i < displayTracks.length; i++) {
      const track = displayTracks[i];
      const y = 100 + i * 60;
      
      // Alternate row background - glass panels effect
      const rowGradient = ctx.createLinearGradient(0, y - 20, 0, y + 40);
      if (i % 2 === 0) {
        rowGradient.addColorStop(0, 'rgba(54, 57, 63, 0.85)');
        rowGradient.addColorStop(1, 'rgba(54, 57, 63, 0.7)');
      } else {
        rowGradient.addColorStop(0, 'rgba(47, 49, 54, 0.85)');
        rowGradient.addColorStop(1, 'rgba(47, 49, 54, 0.7)');
      }
      
      ctx.fillStyle = rowGradient;
      
      // Rounded rectangle for each track
      const rowRadius = 10;
      ctx.beginPath();
      ctx.roundRect(10, y - 20, canvas.width - 20, 60, rowRadius);
      ctx.fill();
      
      // Top highlight to enhance glass effect
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.07)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(20, y - 19);
      ctx.lineTo(canvas.width - 20, y - 19);
      ctx.stroke();
      
      // Position badge with glowing effect
      const badgeGradient = ctx.createRadialGradient(30, y, 2, 30, y, 18);
      badgeGradient.addColorStop(0, '#8ea1e1');
      badgeGradient.addColorStop(0.7, '#5865f2');
      badgeGradient.addColorStop(1, '#4752c4');
      ctx.fillStyle = badgeGradient;
      ctx.beginPath();
      ctx.arc(30, y, 15, 0, Math.PI * 2);
      ctx.fill();
      
      // Badge highlight
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(30, y - 5, 7, 0.8 * Math.PI, 1.8 * Math.PI);
      ctx.stroke();
      
      // Position number
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 16px sans-serif';
      ctx.fillText((i + 1).toString(), i < 9 ? 26 : 22, y + 5);
      
      // Track thumbnail area with gradient background
      const thumbnailGradient = ctx.createLinearGradient(60, y - 20, 110, y + 20);
      thumbnailGradient.addColorStop(0, '#5865f2');
      thumbnailGradient.addColorStop(1, '#4752c4');
      
      ctx.fillStyle = thumbnailGradient;
      ctx.roundRect(60, y - 15, 50, 40, 5);
      ctx.fill();
      
      // Try to load thumbnail as image
      try {
        if (track.thumbnail) {
          // We have the placeholder gradient already rendered
          // Draw music note icon in the thumbnail area
          ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
          ctx.font = 'bold 20px sans-serif';
          ctx.fillText('♫', 78, y + 8);
        }
      } catch (err) {
        console.error("Error handling thumbnail:", err);
      }
      
      // Track title with text shadow
      ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
      ctx.shadowBlur = 5;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 1;
      ctx.font = 'bold 18px sans-serif';
      ctx.fillStyle = '#ffffff';
      
      // Truncate title if too long
      let title;
      if (track.title && track.title !== 'undefined') {
        title = track.title;
      } else if (track.url) {
        // Extract domain name from URL as a fallback
        try {
          const domain = new URL(track.url).hostname.replace('www.', '');
          title = `Song from ${domain}`;
        } catch (err) {
          // If URL parsing fails, use a portion of the URL directly
          const shortUrl = track.url.substring(0, 30).replace(/^https?:\/\//i, '');
          title = `Song from ${shortUrl}...`;
        }
      } else {
        title = 'Untitled Track';
      }
      
      if (title.length > 45) {
        title = title.substring(0, 45) + "...";
      }
      ctx.fillText(title, 120, y);
      
      // Reset shadow for other text
      ctx.shadowBlur = 2;
      
      // Artist name
      if (track.author) {
        ctx.font = '14px sans-serif';
        ctx.fillStyle = '#b9bbbe';
        ctx.fillText(track.author, 120, y + 20);
      }
      
      // Reset shadow
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
      
      // Duration with glass-like button effect
      if (track.duration) {
        const minutes = Math.floor(track.duration / 60000);
        const seconds = Math.floor((track.duration % 60000) / 1000);
        const duration = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        
        // Duration badge
        const durationGradient = ctx.createLinearGradient(canvas.width - 80, y - 10, canvas.width - 20, y + 10);
        durationGradient.addColorStop(0, 'rgba(114, 137, 218, 0.3)');
        durationGradient.addColorStop(1, 'rgba(88, 101, 242, 0.4)');
        
        ctx.fillStyle = durationGradient;
        ctx.beginPath();
        ctx.roundRect(canvas.width - 80, y - 10, 60, 20, 10);
        ctx.fill();
        
        // Duration text
        ctx.font = 'bold 14px sans-serif';
        ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
        ctx.fillText(duration, canvas.width - 62, y + 5);
      }
    }
    
    // If there are more tracks than we're showing
    if (hasMore) {
      const y = 100 + displayTracks.length * 60 + 10;
      
      // Semi-transparent panel for "more tracks" message
      const moreGradient = ctx.createLinearGradient(0, y, 0, y + 30);
      moreGradient.addColorStop(0, 'rgba(47, 49, 54, 0.5)');
      moreGradient.addColorStop(1, 'rgba(47, 49, 54, 0.3)');
      
      ctx.fillStyle = moreGradient;
      ctx.beginPath();
      ctx.roundRect(canvas.width/2 - 150, y, 300, 30, 15);
      ctx.fill();
      
      // Glass effect highlight
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(canvas.width/2 - 140, y + 1);
      ctx.lineTo(canvas.width/2 + 140, y + 1);
      ctx.stroke();
      
      ctx.font = 'italic 16px sans-serif';
      ctx.fillStyle = '#b9bbbe';
      ctx.textAlign = 'center';
      ctx.fillText(`... and ${playlist.tracks.length - 10} more tracks`, canvas.width/2, y + 20);
      ctx.textAlign = 'left';
    }
    
    const buffer = canvas.toBuffer();
    
    await interaction.editReply({
      content: `📝 **Playlist: ${name}**`,
      files: [{ attachment: buffer, name: 'playlist_view.png' }]
    });
  } catch (error) {
    console.error(error);
    await interaction.editReply({ 
      content: 'There was an error viewing the playlist.',
    });
  }
}

/**
 * Handle the play subcommand
 */
async function handlePlay(interaction, client) {
  const name = interaction.options.getString('name');
  const sanitizedName = sanitizeFilename(name);
  const filePath = path.join(PLAYLISTS_DIR, `${sanitizedName}.json`);
  
  if (!fs.existsSync(filePath)) {
    return interaction.reply({ 
      content: `❌ Playlist "${name}" doesn't exist.`,
      ephemeral: true
    });
  }
  
  await interaction.deferReply();
  
  try {
    const playlist = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    
    if (!playlist.tracks || !Array.isArray(playlist.tracks) || playlist.tracks.length === 0) {
      return interaction.editReply(`Playlist **${name}** is empty. Add tracks with \`/playlist add\``);
    }

    // Get or create player
    const { channelId } = interaction.member.voice;
    if (!channelId) {
      return interaction.editReply('You need to be in a voice channel to play music!');
    }

    let player = client.riffy.players.get(interaction.guildId);
    if (!player) {
      player = client.riffy.createConnection({
        guildId: interaction.guildId,
        voiceChannel: channelId,
        textChannel: interaction.channelId,
      });
    }

    // Add all tracks from playlist to queue
    let tracks = 0;
    for (const track of playlist.tracks) {
      // Skip invalid tracks
      if (!track.url) continue;
      
      const result = await client.riffy.resolve(track.url);
      if (result && result.tracks.length > 0) {
        const resolvedTrack = result.tracks[0];
        
        // If the playlist has a custom title for the track, use that instead
        if (track.title && !resolvedTrack.title) {
          resolvedTrack.title = track.title;
        }
        
        // If the playlist has a custom author for the track, use that instead
        if (track.author && !resolvedTrack.author) {
          resolvedTrack.author = track.author;
        }
        
        player.queue.add(resolvedTrack);
        tracks++;
      }
    }

    // Start player if not already playing
    if (!player.playing && !player.paused && player.queue.size > 0) {
      player.play();
    }
    
    await interaction.editReply(`🎵 Added **${tracks}** tracks from playlist **${name}** to the queue`);
  } catch (error) {
    console.error(error);
    await interaction.editReply('There was an error playing the playlist.');
  }
}

/**
 * Handle the delete subcommand
 */
async function handleDelete(interaction) {
  const name = interaction.options.getString('name');
  const sanitizedName = sanitizeFilename(name);
  const filePath = path.join(PLAYLISTS_DIR, `${sanitizedName}.json`);
  
  if (!fs.existsSync(filePath)) {
    return interaction.reply({ 
      content: `❌ Playlist "${name}" doesn't exist.`,
      ephemeral: true
    });
  }
  
  try {
    fs.unlinkSync(filePath);
    await interaction.reply(`✅ Deleted playlist: **${name}**`);
  } catch (error) {
    console.error(error);
    await interaction.reply({ 
      content: 'There was an error deleting the playlist.',
      ephemeral: true 
    });
  }
}

/**
 * Sanitize a filename to avoid path traversal and invalid characters
 */
function sanitizeFilename(name) {
  return name.replace(/[/\\?%*:|"<>]/g, '_').toLowerCase();
}