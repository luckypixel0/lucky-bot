const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shuffle')
    .setDescription('Shuffle the current queue'),

  async execute(interaction, client) {
    const player = client.riffy.players.get(interaction.guildId);

    if (!player) {
      return interaction.reply({ content: 'There is no active music session.', ephemeral: true });
    }

    const queue = player.queue;
    if (!queue || queue.length < 2) {
      return interaction.reply({ 
        content: 'Need at least 2 tracks in the queue to shuffle.', 
        ephemeral: true 
      });
    }

    try {
      player.queue.shuffle();
      await interaction.reply('🔀 Queue has been shuffled!');
    } catch (error) {
      console.error(error);
      await interaction.reply('There was an error trying to shuffle the queue.');
    }
  }
}; 