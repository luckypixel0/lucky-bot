const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createCanvas, loadImage } = require('canvas');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Display all available commands')
    .addStringOption(option =>
      option.setName('command')
        .setDescription('Get detailed information about a specific command')
        .setRequired(false)
    ),

  async execute(interaction, client) {
    const commandName = interaction.options.getString('command');
    
    // If a specific command is requested
    if (commandName) {
      const command = client.commands.get(commandName);
      
      if (!command) {
        return interaction.reply({
          content: `Command \`${commandName}\` not found.`,
          ephemeral: true
        });
      }
      
      return interaction.reply({
        embeds: [createCommandEmbed(command)],
        ephemeral: true
      });
    }
    
    await interaction.deferReply();
    
    try {
      // All available commands
      const commands = [...client.commands.values()];
      
      // Categorize commands
      const categories = {
        'Player Controls': ['play', 'pause', 'resume', 'skip', 'stop', 'seek', 'volume'],
        'Queue Management': ['queue', 'nowplaying', 'loop', 'shuffle', 'playlist'],
        'Utility': ['help']
      };
      
      // Create canvas for help menu header
      const canvas = await createHelpMenuCanvas();
      
      // Create main embed
      const helpEmbed = new EmbedBuilder()
        .setColor('#1DB954')
        .setTitle('Music Bot Commands')
        .setDescription('Here are all available commands categorized for easy navigation.')
        .setImage('attachment://help-banner.png')
        .setFooter({ text: `Total Commands: ${commands.length} • Use /help [command] for detailed info` });
      
      // Add fields for each category
      for (const [category, commandNames] of Object.entries(categories)) {
        const validCommands = commandNames
          .filter(name => client.commands.has(name))
          .map(name => {
            const cmd = client.commands.get(name);
            return `\`/${cmd.data.name}\` - ${cmd.data.description}`;
          })
          .join('\n');
        
        if (validCommands) {
          helpEmbed.addFields({ name: `${category}`, value: validCommands });
        }
      }
      
      // Create buttons with updated custom IDs to match handler in index.js
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('help_player_controls')
            .setLabel('Player Controls')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId('help_queue')
            .setLabel('Queue Management')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('help_utility')
            .setLabel('Utility')
            .setStyle(ButtonStyle.Secondary)
        );
      
      await interaction.editReply({
        embeds: [helpEmbed],
        files: [{ attachment: canvas.toBuffer(), name: 'help-banner.png' }],
        components: [row]
      });
    } catch (error) {
      console.error(error);
      await interaction.followUp({ 
        content: 'There was an error displaying the help menu.', 
        ephemeral: true 
      });
    }
  }
};

// Helper function to create individual command embeds
function createCommandEmbed(command) {
  const embed = new EmbedBuilder()
    .setColor('#1DB954')
    .setTitle(`/${command.data.name}`)
    .setDescription(command.data.description);
  
  // Add options if they exist
  if (command.data.options && command.data.options.length > 0) {
    const options = command.data.options.map(option => {
      return `\`${option.name}\` - ${option.description}${option.required ? ' (Required)' : ' (Optional)'}`;
    }).join('\n');
    
    embed.addFields({ name: 'Options', value: options });
  }
  
  // Add usage example
  let usage = `/${command.data.name}`;
  if (command.data.options && command.data.options.length > 0) {
    const requiredOptions = command.data.options
      .filter(opt => opt.required)
      .map(opt => `[${opt.name}]`)
      .join(' ');
    
    const optionalOptions = command.data.options
      .filter(opt => !opt.required)
      .map(opt => `(${opt.name})`)
      .join(' ');
    
    if (requiredOptions) usage += ` ${requiredOptions}`;
    if (optionalOptions) usage += ` ${optionalOptions}`;
  }
  
  embed.addFields({ name: 'Usage', value: `\`${usage}\`` });
  
  return embed;
}

// Helper function to create canvas for help menu
async function createHelpMenuCanvas() {
  const width = 700;
  const height = 180;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  
  // Background with gradient
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, '#1DB954');  // Spotify green
  gradient.addColorStop(1, '#191414');  // Dark shade
  
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);
  
  // Add rounded corners
  const cornerRadius = 25;
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(cornerRadius, 0);
  ctx.lineTo(width - cornerRadius, 0);
  ctx.quadraticCurveTo(width, 0, width, cornerRadius);
  ctx.lineTo(width, height - cornerRadius);
  ctx.quadraticCurveTo(width, height, width - cornerRadius, height);
  ctx.lineTo(cornerRadius, height);
  ctx.quadraticCurveTo(0, height, 0, height - cornerRadius);
  ctx.lineTo(0, cornerRadius);
  ctx.quadraticCurveTo(0, 0, cornerRadius, 0);
  ctx.closePath();
  ctx.clip();
  
  // Add music note decoration
  try {
    const musicIcon = await loadImage('https://cdn.discordapp.com/attachments/1112068764203888751/1219123837913112616/music_note_icon.png');
    ctx.globalAlpha = 0.2;
    ctx.drawImage(musicIcon, width - 150, 20, 120, 120);
    ctx.globalAlpha = 1.0;
  } catch (error) {
    console.error('Error loading music icon:', error);
  }
  
  // Add text
  ctx.font = 'bold 48px Arial';
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText('Help Menu', 40, 75);
  
  ctx.font = '24px Arial';
  ctx.fillText('Music Commands & Features', 40, 120);
  
  return canvas;
} 