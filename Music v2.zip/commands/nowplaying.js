const { SlashCommandBuilder } = require('discord.js');
const { createCanvas, loadImage } = require('canvas');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nowplaying')
    .setDescription('Show information about the currently playing track'),

  async execute(interaction, client) {
    const player = client.riffy.players.get(interaction.guildId);

    // Check if player exists and is actually playing something
    if (!player || (!player.playing && !player.paused) || !player.current) {
      return interaction.reply({ content: 'There is no song playing right now.', ephemeral: true });
    }
    
    console.log('Player status:', { 
      playing: player.playing, 
      paused: player.paused,
      hasCurrent: !!player.current,
      queueLength: player.queue.length 
    });

    await interaction.deferReply();

    try {
      // Get the currently playing track from Riffy player
      // In Riffy, the current playing track is accessed via player.current
      const track = player.current || player.currentTrack;
      
      if (!track || !track.info) {
        return interaction.editReply({ content: 'Unable to retrieve track information.' });
      }
      
      console.log('Now playing track:', track.info?.title);
      
      // Get playback position and total length (in ms)
      const position = player.position || 0;
      const duration = track.info.length || 0;
      
      // Create canvas for now playing info
      const canvasWidth = 600;
      const canvasHeight = 140; // Further reduced height to match the image better
      const canvas = createCanvas(canvasWidth, canvasHeight);
      const ctx = canvas.getContext('2d');

      // Clean dark background
      ctx.fillStyle = '#0A0A0A';
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);
      
      // Subtle gradient overlay
      const gradient = ctx.createLinearGradient(0, 0, canvasWidth, canvasHeight);
      gradient.addColorStop(0, 'rgba(30, 30, 30, 0.5)');
      gradient.addColorStop(1, 'rgba(10, 10, 10, 0.8)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);

      // Create rounded corners
      const cornerRadius = 25;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cornerRadius, 0);
      ctx.lineTo(canvasWidth - cornerRadius, 0);
      ctx.quadraticCurveTo(canvasWidth, 0, canvasWidth, cornerRadius);
      ctx.lineTo(canvasWidth, canvasHeight - cornerRadius);
      ctx.quadraticCurveTo(canvasWidth, canvasHeight, canvasWidth - cornerRadius, canvasHeight);
      ctx.lineTo(cornerRadius, canvasHeight);
      ctx.quadraticCurveTo(0, canvasHeight, 0, canvasHeight - cornerRadius);
      ctx.lineTo(0, cornerRadius);
      ctx.quadraticCurveTo(0, 0, cornerRadius, 0);
      ctx.closePath();
      ctx.clip();
      
      // Add subtle card border
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(5, 5, canvasWidth - 10, canvasHeight - 10, 24);
      ctx.stroke();

      let albumArt;
      try {
        albumArt = await loadImage(track.info.thumbnail);
      } catch (error) {
        console.error('Error loading album art:', error);
        albumArt = null;
      }

      // Image positioning - increased size as requested
      const imageSize = 100; // Larger size as requested
      const imageX = 20;
      const imageY = 20; // Consistent spacing

      if (albumArt) {
        // Create separate blurred background
        const bgCanvas = createCanvas(canvasWidth, canvasHeight);
        const bgCtx = bgCanvas.getContext('2d');
        
        // Calculate dimensions to cover the entire background
        const aspectRatio = albumArt.width / albumArt.height;
        let bgWidth = canvasWidth;
        let bgHeight = canvasWidth / aspectRatio;
        
        if (bgHeight < canvasHeight) {
          bgHeight = canvasHeight;
          bgWidth = canvasHeight * aspectRatio;
        }
        
        // Center the image
        const bgX = (canvasWidth - bgWidth) / 2;
        const bgY = (canvasHeight - bgHeight) / 2;
        
        // Draw enlarged image
        bgCtx.drawImage(albumArt, bgX, bgY, bgWidth, bgHeight);
        
        // Simulate blur effect
        bgCtx.globalAlpha = 0.3;
        for (let i = -3; i <= 3; i++) {
          for (let j = -3; j <= 3; j++) {
            bgCtx.drawImage(bgCanvas, i, j, canvasWidth, canvasHeight);
          }
        }
        
        // Draw blurred background
        ctx.globalAlpha = 0.2;
        ctx.drawImage(bgCanvas, 0, 0, canvasWidth, canvasHeight);
        ctx.globalAlpha = 1.0;

        // Draw album art with rounded corners
        const radius = 15;
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(imageX + radius, imageY);
        ctx.lineTo(imageX + imageSize - radius, imageY);
        ctx.quadraticCurveTo(imageX + imageSize, imageY, imageX + imageSize, imageY + radius);
        ctx.lineTo(imageX + imageSize, imageY + imageSize - radius);
        ctx.quadraticCurveTo(imageX + imageSize, imageY + imageSize, imageX + imageSize - radius, imageY + imageSize);
        ctx.lineTo(imageX + radius, imageY + imageSize);
        ctx.quadraticCurveTo(imageX, imageY + imageSize, imageX, imageY + imageSize - radius);
        ctx.lineTo(imageX, imageY + radius);
        ctx.quadraticCurveTo(imageX, imageY, imageX + radius, imageY);
        ctx.closePath();
        ctx.clip();
        
        // Add subtle shadow
        ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
        ctx.shadowBlur = 10;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 4;
        
        ctx.drawImage(albumArt, imageX, imageY, imageSize, imageSize);
        ctx.restore();

        // Reset shadow
        ctx.shadowColor = 'transparent';
        ctx.shadowBlur = 0;
      } else {
        // Placeholder if no album art
        ctx.fillStyle = '#333333';
        ctx.fillRect(imageX, imageY, imageSize, imageSize);
      }

      // Text positioning - aligned with the album art end
      const textLeftMargin = imageX + imageSize + 40; // Start text closer to album art
      const titleY = 45; // Fixed position in upper area
      const nowPlayingY = titleY + 35; // Added more space between title and NOW PLAYING text
      
      // Draw title - larger as in the image
      ctx.fillStyle = '#FFFFFF';
      ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
      ctx.shadowBlur = 4;
      ctx.shadowOffsetX = 1;
      ctx.shadowOffsetY = 1;
      ctx.font = 'bold 40px sans-serif'; // Larger font size for better visibility
      ctx.textBaseline = 'middle';
      
      // Truncate title if needed
      const maxTitleWidth = canvasWidth - textLeftMargin - 30;
      let title = track.info.title;
      if (ctx.measureText(title).width > maxTitleWidth) {
        while (ctx.measureText(title + '...').width > maxTitleWidth && title.length > 0) {
          title = title.slice(0, -1);
        }
        title += '...';
      }
      ctx.fillText(title, textLeftMargin, titleY);
      
      // Draw "NOW PLAYING" text below title - larger text as requested
      ctx.textAlign = 'left';
      ctx.font = '14px sans-serif'; // Increased size
      ctx.fillStyle = '#999999'; // Gray color like in the image
      ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
      ctx.shadowBlur = 1;
      ctx.fillText('NOW PLAYING', textLeftMargin, nowPlayingY);

      // Time formatting
      const currentTime = formatTime(position);
      const totalTime = formatTime(duration);
      
      // Position for time indicators and progress bar at bottom
      const timeY = canvasHeight - 25; // Position time text closer to bottom
      const progressBarY = timeY - 15; // Progress bar right above time text
      const progressBarHeight = 4; // Thinner progress bar like in image
      const progressBarWidth = canvasWidth - (imageX + imageSize + 60); // Adjust width to start after album art
      const progressBarX = imageX + imageSize + 40; // Start progress bar after album art with spacing - adjusted for larger avatar
      
      // Draw time text first
      ctx.font = '14px sans-serif';
      ctx.fillStyle = '#FFFFFF';
      ctx.textAlign = 'left';
      ctx.fillText(currentTime, progressBarX, timeY);
      ctx.textAlign = 'right';
      ctx.fillText(totalTime, progressBarX + progressBarWidth, timeY);
      
      // Now draw progress bar between the times
      // Progress bar background - very subtle
      ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
      ctx.beginPath();
      ctx.roundRect(progressBarX, progressBarY, progressBarWidth, progressBarHeight, 2);
      ctx.fill();
      
      // Calculate progress
      const progress = position / duration;
      const progressWidth = Math.max(0, Math.min(progress * progressBarWidth, progressBarWidth));
      
      // Add white dot at current position
      const dotX = progressBarX + progressWidth;
      const dotRadius = 4;
      
      // Draw progress with white color
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.roundRect(progressBarX, progressBarY, progressWidth, progressBarHeight, 2);
      ctx.fill();
      
      // Draw white circle at current position
      ctx.beginPath();
      ctx.arc(dotX, progressBarY + progressBarHeight/2, dotRadius, 0, Math.PI * 2);
      ctx.fill();

      // Reset text alignment
      ctx.textAlign = 'left';
      
      const buffer = canvas.toBuffer();

      await interaction.editReply({
        files: [{ attachment: buffer, name: 'now-playing.png' }]
      });
    } catch (error) {
      console.error(error);
      await interaction.editReply('There was an error trying to show the currently playing track.');
    }
  }
};

// Format milliseconds to MM:SS
function formatTime(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
} 