const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('seek')
    .setDescription('Seek to a specific position in the current track')
    .addStringOption(option =>
      option.setName('position')
        .setDescription('Position to seek to (e.g., 1:30, 2:45)')
        .setRequired(true)),

  async execute(interaction, client) {
    const player = client.riffy.players.get(interaction.guildId);

    if (!player || !player.playing) {
      return interaction.reply({ 
        content: 'There is no track playing right now.', 
        ephemeral: true 
      });
    }

    const positionInput = interaction.options.getString('position');
    
    // Convert time format (e.g., 1:30) to milliseconds
    const milliseconds = convertToMilliseconds(positionInput);
    
    if (milliseconds === null) {
      return interaction.reply({ 
        content: 'Invalid time format. Please use m:ss format (e.g., 1:30, 2:45).',
        ephemeral: true 
      });
    }

    try {
      player.seek(milliseconds);
      await interaction.reply(`⏩ Seeked to ${positionInput}`);
    } catch (error) {
      console.error(error);
      await interaction.reply('There was an error trying to seek in the track.');
    }
  }
};

/**
 * Converts a time string to milliseconds
 * @param {string} timeString - Time string in format m:ss or mm:ss
 * @returns {number|null} - Time in milliseconds or null if invalid
 */
function convertToMilliseconds(timeString) {
  // Match format m:ss or mm:ss
  const match = timeString.match(/^(\d{1,2}):([0-5]\d)$/);
  if (!match) return null;
  
  const minutes = parseInt(match[1]);
  const seconds = parseInt(match[2]);
  
  return (minutes * 60 + seconds) * 1000;
} 