const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('resume')
    .setDescription('Resume the currently paused track'),

  async execute(interaction, client) {
    const player = client.riffy.players.get(interaction.guildId);

    if (!player) {
      return interaction.reply({ content: 'There is no music session active.', ephemeral: true });
    }

    if (!player.paused) {
      return interaction.reply({ content: 'The player is already playing song.', ephemeral: true });
    }

    try {
      player.pause(false);
      await interaction.reply('▶️ Resumed the current track.');
    } catch (error) {
      console.error(error);
      await interaction.reply('There was an error trying to resume the track.');
    }
  }
}; 