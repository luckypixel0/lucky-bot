const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('loop')
    .setDescription('Set loop mode for the current playback')
    .addStringOption(option =>
      option.setName('mode')
        .setDescription('The loop mode to set')
        .setRequired(true)
        .addChoices(
          { name: 'Off', value: 'off' },
          { name: 'Track', value: 'track' },
          { name: 'Queue', value: 'queue' }
        )),

  async execute(interaction, client) {
    const player = client.riffy.players.get(interaction.guildId);

    if (!player || !player.playing) {
      return interaction.reply({ 
        content: 'There is no track playing right now.', 
        ephemeral: true 
      });
    }

    const loopMode = interaction.options.getString('mode');
    
    try {
      switch (loopMode) {
        case 'off':
          player.setLoop('none');
          await interaction.reply('🔄 Loop mode: **Disabled**');
          break;
        case 'track':
          player.setLoop('track');
          await interaction.reply('🔂 Loop mode: **Current Track**');
          break;
        case 'queue':
          player.setLoop('queue');
          await interaction.reply('🔁 Loop mode: **Queue**');
          break;
      }
    } catch (error) {
      console.error(error);
      await interaction.reply('There was an error trying to set the loop mode.');
    }
  }
}; 