const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stop')
    .setDescription('Stop the music and leave the voice channel'),

  async execute(interaction, client) {
    const player = client.riffy.players.get(interaction.guildId);

    if (!player) {
      return interaction.reply({ content: 'There is no music playing right now.', ephemeral: true });
    }

    await interaction.deferReply();

    try {
      player.destroy();
      await interaction.editReply('Stopped the music and left the voice channel.');
    } catch (error) {
      console.error(error);
      await interaction.editReply('There was an error trying to stop the music.');
    }
  }
};
