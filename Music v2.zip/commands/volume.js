const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('volume')
    .setDescription('Change or check the player volume')
    .addIntegerOption(option =>
      option.setName('level')
        .setDescription('Volume level (0-100)')
        .setMinValue(0)
        .setMaxValue(100)
        .setRequired(false)),

  async execute(interaction, client) {
    const player = client.riffy.players.get(interaction.guildId);
    
    if (!player) {
      return interaction.reply({ content: 'There is no active music session.', ephemeral: true });
    }

    const volumeLevel = interaction.options.getInteger('level');

    // If no volume level is provided, return the current volume
    if (volumeLevel === null) {
      return interaction.reply(`🔊 Current volume: ${player.volume}%`);
    }
    
    try {
      player.setVolume(volumeLevel);
      
      let volumeIcon = '🔇';
      if (volumeLevel > 0 && volumeLevel <= 30) volumeIcon = '🔈';
      else if (volumeLevel > 30 && volumeLevel <= 70) volumeIcon = '🔉';
      else if (volumeLevel > 70) volumeIcon = '🔊';
      
      await interaction.reply(`${volumeIcon} Volume set to ${volumeLevel}%`);
    } catch (error) {
      console.error(error);
      await interaction.reply('There was an error trying to change the volume.');
    }
  }
}; 