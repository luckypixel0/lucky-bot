const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('skip')
    .setDescription('Skip the currently playing track'),

  async execute(interaction, client) {
    const player = client.riffy.players.get(interaction.guildId);

    if (!player || !player.playing) {
      return interaction.reply({ content: 'There is no track playing right now.', ephemeral: true });
    }

    await interaction.deferReply();

    try {
      player.stop();
      await interaction.editReply('Skipped the current track.');
    } catch (error) {
      console.error(error);
      await interaction.editReply('There was an error trying to skip the track.');
    }
  }
};
