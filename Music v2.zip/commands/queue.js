const { SlashCommandBuilder } = require('discord.js');
const { createCanvas, loadImage } = require('canvas');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('queue')
    .setDescription('Show the current music queue'),

  async execute(interaction, client) {
    const player = client.riffy.players.get(interaction.guildId);

    if (!player || !player.queue.size) {
      return interaction.reply({ content: 'The queue is currently empty.', ephemeral: true });
    }

    await interaction.deferReply();

    try {
      const queue = player.queue.slice(0, 10); // Show up to 10 tracks
      const currentTrack = player.currentTrack;

      // Create canvas for queue with fixed height
      const canvasWidth = 600;
      const headerHeight = 80;
      const itemHeight = 60;
      const canvasHeight = headerHeight + (queue.length * itemHeight);
      const canvas = createCanvas(canvasWidth, canvasHeight);
      const ctx = canvas.getContext('2d');

      // Clean dark background
      ctx.fillStyle = '#0A0A0A';
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);
      
      // Subtle gradient overlay
      const gradient = ctx.createLinearGradient(0, 0, canvasWidth, canvasHeight);
      gradient.addColorStop(0, 'rgba(30, 30, 30, 0.5)');
      gradient.addColorStop(1, 'rgba(10, 10, 10, 0.8)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);

      // Create rounded corners
      const cornerRadius = 25;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cornerRadius, 0);
      ctx.lineTo(canvasWidth - cornerRadius, 0);
      ctx.quadraticCurveTo(canvasWidth, 0, canvasWidth, cornerRadius);
      ctx.lineTo(canvasWidth, canvasHeight - cornerRadius);
      ctx.quadraticCurveTo(canvasWidth, canvasHeight, canvasWidth - cornerRadius, canvasHeight);
      ctx.lineTo(cornerRadius, canvasHeight);
      ctx.quadraticCurveTo(0, canvasHeight, 0, canvasHeight - cornerRadius);
      ctx.lineTo(0, cornerRadius);
      ctx.quadraticCurveTo(0, 0, cornerRadius, 0);
      ctx.closePath();
      ctx.clip();

      // Add subtle card border
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(5, 5, canvasWidth - 10, canvasHeight - 10, 24);
      ctx.stroke();
      
      // Draw header with gradient
      const headerGradient = ctx.createLinearGradient(0, 0, canvasWidth, headerHeight);
      headerGradient.addColorStop(0, 'rgba(30, 30, 30, 0.7)');
      headerGradient.addColorStop(1, 'rgba(0, 0, 0, 0.7)');
      ctx.fillStyle = headerGradient;
      ctx.fillRect(0, 0, canvasWidth, headerHeight);
      
      // Header text with shadow
      ctx.font = 'bold 32px sans-serif';
      ctx.fillStyle = '#FFFFFF';
      ctx.textBaseline = 'middle';
      ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
      ctx.shadowBlur = 4;
      ctx.shadowOffsetX = 1;
      ctx.shadowOffsetY = 1;
      ctx.fillText('Music Queue', 30, headerHeight / 2);
      
      // Show number of tracks
      ctx.font = '18px sans-serif';
      ctx.fillStyle = '#CCCCCC';
      ctx.textAlign = 'right';
      ctx.fillText(`${player.queue.size} tracks in queue`, canvasWidth - 30, headerHeight / 2);
      
      // Reset shadow
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
      ctx.textAlign = 'left';
      
      // Draw separator line
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(20, headerHeight - 1);
      ctx.lineTo(canvasWidth - 20, headerHeight - 1);
      ctx.stroke();

      // Load and cache thumbnails
      const thumbnails = [];
      for (const track of queue) {
        try {
          const thumbnail = await loadImage(track.info.thumbnail);
          thumbnails.push(thumbnail);
        } catch (error) {
          thumbnails.push(null); // If thumbnail can't be loaded
        }
      }

      // Draw each track in the queue
      for (let i = 0; i < queue.length; i++) {
        const track = queue[i];
        const y = headerHeight + (i * itemHeight);
        
        // Track background highlight for alternating rows
        if (i % 2 === 0) {
          ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
          ctx.fillRect(0, y, canvasWidth, itemHeight);
        }
        
        // Draw position number badge with gradient
        const badgeSize = 26;
        const badgeX = 30;
        const badgeY = y + (itemHeight / 2);
        
        // Create subtle badge gradient
        const badgeGradient = ctx.createRadialGradient(
          badgeX, badgeY, 0,
          badgeX, badgeY, badgeSize/2
        );
        badgeGradient.addColorStop(0, 'rgba(60, 60, 60, 0.4)');
        badgeGradient.addColorStop(1, 'rgba(30, 30, 30, 0.6)');
        
        ctx.fillStyle = badgeGradient;
        ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
        ctx.shadowBlur = 4;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 2;
        ctx.beginPath();
        ctx.arc(badgeX, badgeY, badgeSize / 2, 0, Math.PI * 2);
        ctx.fill();
        
        // Reset shadow
        ctx.shadowColor = 'transparent';
        ctx.shadowBlur = 0;
        
        ctx.font = 'bold 16px sans-serif';
        ctx.fillStyle = '#FFFFFF';
        ctx.textBaseline = 'middle';
        ctx.textAlign = 'center';
        ctx.fillText((i + 1).toString(), badgeX, badgeY);
        ctx.textAlign = 'left';
        
        // Draw thumbnail if available
        const thumbSize = 40;
        const thumbX = 70;
        const thumbY = y + (itemHeight / 2) - (thumbSize / 2);
        
        if (thumbnails[i]) {
          // Draw rounded thumbnail
          ctx.save();
          ctx.beginPath();
          const thumbRadius = 5;
          ctx.moveTo(thumbX + thumbRadius, thumbY);
          ctx.lineTo(thumbX + thumbSize - thumbRadius, thumbY);
          ctx.quadraticCurveTo(thumbX + thumbSize, thumbY, thumbX + thumbSize, thumbY + thumbRadius);
          ctx.lineTo(thumbX + thumbSize, thumbY + thumbSize - thumbRadius);
          ctx.quadraticCurveTo(thumbX + thumbSize, thumbY + thumbSize, thumbX + thumbSize - thumbRadius, thumbY + thumbSize);
          ctx.lineTo(thumbX + thumbRadius, thumbY + thumbSize);
          ctx.quadraticCurveTo(thumbX, thumbY + thumbSize, thumbX, thumbY + thumbSize - thumbRadius);
          ctx.lineTo(thumbX, thumbY + thumbRadius);
          ctx.quadraticCurveTo(thumbX, thumbY, thumbX + thumbRadius, thumbY);
          ctx.closePath();
          ctx.clip();
          ctx.drawImage(thumbnails[i], thumbX, thumbY, thumbSize, thumbSize);
          ctx.restore();
        } else {
          // Placeholder for missing thumbnail
          ctx.fillStyle = '#333333';
          ctx.fillRect(thumbX, thumbY, thumbSize, thumbSize);
        }
        
        // Draw track title
        const textX = thumbX + thumbSize + 15;
        const titleY = y + 22;
        const authorY = y + 42;
        const maxTitleWidth = canvasWidth - textX - 100;
        
        ctx.font = 'bold 18px sans-serif';
        ctx.fillStyle = '#FFFFFF';
        
        // Add subtle text shadow for better readability
        ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
        ctx.shadowBlur = 3;
        ctx.shadowOffsetX = 1;
        ctx.shadowOffsetY = 1;
        
        // Check if this track is currently playing
        const isCurrentTrack = currentTrack && track.track === currentTrack.track;
        
        // Add playing indicator for current track
        if (isCurrentTrack) {
          // Draw playing indicator
          ctx.fillStyle = '#4CAF50'; // Green indicator
          ctx.beginPath();
          ctx.arc(textX - 10, titleY, 4, 0, Math.PI * 2);
          ctx.fill();
          
          // Move title to make room for indicator
          textX += 5;
          ctx.fillStyle = '#FFFFFF';
        }
        
        let title = track.info.title;
        if (ctx.measureText(title).width > maxTitleWidth) {
          // Truncate title if too long
          while (ctx.measureText(title + '...').width > maxTitleWidth && title.length > 0) {
            title = title.slice(0, -1);
          }
          title += '...';
        }
        ctx.fillText(title, textX, titleY);
        
        // Reset shadow
        ctx.shadowColor = 'transparent';
        ctx.shadowBlur = 0;
        
        // Draw author name
        ctx.font = '14px sans-serif';
        ctx.fillStyle = '#AAAAAA';
        ctx.fillText(track.info.author, textX, authorY);
        
        // Draw duration at right side
        if (track.info.length) {
          const duration = formatDuration(track.info.length);
          ctx.font = '14px sans-serif';
          ctx.fillStyle = '#999999';
          ctx.textAlign = 'right';
          ctx.fillText(duration, canvasWidth - 25, y + (itemHeight / 2));
          ctx.textAlign = 'left';
        }
      }

      const buffer = canvas.toBuffer();

      await interaction.editReply({
        content: `Current music queue (${player.queue.size} tracks):`,
        files: [{ attachment: buffer, name: 'queue.png' }]
      });
    } catch (error) {
      console.error(error);
      await interaction.editReply('There was an error trying to show the queue.');
    }
  }
};

// Helper function to format duration
function formatDuration(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}
