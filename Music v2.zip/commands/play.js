const { SlashCommandBuilder } = require('discord.js');
const { createCanvas } = require('canvas');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Play a song from YouTube or other sources')
    .addStringOption(option =>
      option.setName('query')
        .setDescription('The song name or URL to play')
        .setRequired(true)
    ),

  async execute(interaction, client) {
    const query = interaction.options.getString('query');
    const member = interaction.member;
    const voiceChannel = member.voice.channel;

    if (!voiceChannel) {
      return interaction.reply({ content: 'You need to be in a voice channel to play music!', ephemeral: true });
    }

    await interaction.deferReply();

    try {
      // Create a player connection
      const player = client.riffy.createConnection({
        guildId: interaction.guildId,
        voiceChannel: voiceChannel.id,
        textChannel: interaction.channelId,
        deaf: true,
      });

      // Resolve the query
      const resolve = await client.riffy.resolve({
        query: query,
        requester: interaction.user,
      });

      console.log('Riffy resolve result:', resolve);

      const { loadType, tracks, playlistInfo } = resolve;

      console.log('Load type:', loadType);
      console.log('Tracks length:', tracks.length);

      if (loadType === 'PLAYLIST_LOADED' || loadType === 'playlist') {
        for (const track of tracks) {
          track.info.requester = interaction.user;
          player.queue.add(track);
        }
        if (!player.playing && !player.paused) await player.play();

        // Create canvas image with playlist info
        const canvas = createCanvas(600, 100);
        const ctx = canvas.getContext('2d');

        ctx.fillStyle = '#1DB954';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.font = '28px sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.fillText(`Added playlist: ${playlistInfo.name}`, 20, 60);

        const buffer = canvas.toBuffer();

        await interaction.editReply({
          content: `Added ${tracks.length} tracks from playlist: ${playlistInfo.name}`,
          files: [{ attachment: buffer, name: 'playlist.png' }]
        });
      } else if (loadType === 'SEARCH_RESULT' || loadType === 'search' || loadType === 'track' || loadType === 'TRACK_LOADED') {
        const track = tracks[0];
        track.info.requester = interaction.user;

        player.queue.add(track);
        if (!player.playing && !player.paused) await player.play();

        // Create canvas image with track info
        const canvasWidth = 600;
        const canvasHeight = 150;
        const canvas = createCanvas(canvasWidth, canvasHeight);
        const ctx = canvas.getContext('2d');

        // Background with album art as banner
        const loadImage = require('canvas').loadImage;

        const imageSize = 130;
        const imageX = 20; // Increased left margin for cleaner look
        const imageY = 10;

        // Clean dark background - no blue/teal tint
        ctx.fillStyle = '#0A0A0A'; // Nearly black for clean look
        ctx.fillRect(0, 0, canvasWidth, canvasHeight);
        
        // Subtle gradient for depth without color tint
        const gradient = ctx.createLinearGradient(0, 0, canvasWidth, canvasHeight);
        gradient.addColorStop(0, 'rgba(30, 30, 30, 0.5)');
        gradient.addColorStop(1, 'rgba(10, 10, 10, 0.8)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvasWidth, canvasHeight);

        // Create rounded corners for the entire canvas - more pronounced like in the image
        const cornerRadius = 25; // Increased radius for more curved corners
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(cornerRadius, 0);
        ctx.lineTo(canvasWidth - cornerRadius, 0);
        ctx.quadraticCurveTo(canvasWidth, 0, canvasWidth, cornerRadius);
        ctx.lineTo(canvasWidth, canvasHeight - cornerRadius);
        ctx.quadraticCurveTo(canvasWidth, canvasHeight, canvasWidth - cornerRadius, canvasHeight);
        ctx.lineTo(cornerRadius, canvasHeight);
        ctx.quadraticCurveTo(0, canvasHeight, 0, canvasHeight - cornerRadius);
        ctx.lineTo(0, cornerRadius);
        ctx.quadraticCurveTo(0, 0, cornerRadius, 0);
        ctx.closePath();
        ctx.clip();

        let albumArt;
        try {
          albumArt = await loadImage(track.info.thumbnail);
        } catch (error) {
          console.error('Error loading album art:', error);
          albumArt = null;
        }

        if (albumArt) {
          // Draw full-size album art as blurred background
          // Create separate blurred background on a separate canvas
          const bgCanvas = createCanvas(canvasWidth, canvasHeight);
          const bgCtx = bgCanvas.getContext('2d');
          
          // Calculate dimensions to cover the entire background without stretching
          const aspectRatio = albumArt.width / albumArt.height;
          let bgWidth = canvasWidth;
          let bgHeight = canvasWidth / aspectRatio;
          
          // If height is too small, calculate based on height instead
          if (bgHeight < canvasHeight) {
            bgHeight = canvasHeight;
            bgWidth = canvasHeight * aspectRatio;
          }
          
          // Center the image
          const bgX = (canvasWidth - bgWidth) / 2;
          const bgY = (canvasHeight - bgHeight) / 2;
          
          // Draw enlarged image to fill background
          bgCtx.drawImage(albumArt, bgX, bgY, bgWidth, bgHeight);
          
          // Simulate blur by drawing multiple transparent overlays
          // (Since we don't have direct access to image filters)
          bgCtx.globalAlpha = 0.3;
          for (let i = -3; i <= 3; i++) {
            for (let j = -3; j <= 3; j++) {
              bgCtx.drawImage(bgCanvas, i, j, canvasWidth, canvasHeight);
            }
          }
          
          // Draw the blurred background with opacity
          ctx.globalAlpha = 0.2; // Slightly stronger than before but still subtle
          ctx.drawImage(bgCanvas, 0, 0, canvasWidth, canvasHeight);
          ctx.globalAlpha = 1.0;

          // Draw album art on left with rounded corners like in the image
          const radius = 15; // Smaller radius like in the image
          ctx.save();
          ctx.beginPath();
          ctx.moveTo(imageX + radius, imageY);
          ctx.lineTo(imageX + imageSize - radius, imageY);
          ctx.quadraticCurveTo(imageX + imageSize, imageY, imageX + imageSize, imageY + radius);
          ctx.lineTo(imageX + imageSize, imageY + imageSize - radius);
          ctx.quadraticCurveTo(imageX + imageSize, imageY + imageSize, imageX + imageSize - radius, imageY + imageSize);
          ctx.lineTo(imageX + radius, imageY + imageSize);
          ctx.quadraticCurveTo(imageX, imageY + imageSize, imageX, imageY + imageSize - radius);
          ctx.lineTo(imageX, imageY + radius);
          ctx.quadraticCurveTo(imageX, imageY, imageX + radius, imageY);
          ctx.closePath();
          ctx.clip();
          
          // Add subtle shadow - less pronounced than before, like in the image
          ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
          ctx.shadowBlur = 10;
          ctx.shadowOffsetX = 0;
          ctx.shadowOffsetY = 4;
          
          // No visible border on album art in the image

          ctx.drawImage(albumArt, imageX, imageY, imageSize, imageSize);
          ctx.restore();

          // Reset shadow
          ctx.shadowColor = 'transparent';
          ctx.shadowBlur = 0;
          ctx.shadowOffsetX = 0;
          ctx.shadowOffsetY = 0;

          // Draw queue number in a clean circular badge on right side like in the image
          const queueIndex = player.queue.findIndex(t => t.track === track.track) + 1;
          const badgeX = canvasWidth - 40;
          const badgeY = canvasHeight / 2; // Center vertically like in the image
          
          // Draw solid light gray circle badge like in the image
          const badgeRadius = 22;
          ctx.shadowColor = 'rgba(0, 0, 0, 0.2)';
          ctx.shadowBlur = 4;
          ctx.shadowOffsetX = 0;
          ctx.shadowOffsetY = 0;
          
          ctx.fillStyle = '#e0e0e0'; // Light gray badge like in the image
          ctx.beginPath();
          ctx.arc(badgeX, badgeY, badgeRadius, 0, Math.PI * 2);
          ctx.fill();

          // Remove shadow for text
          ctx.shadowColor = 'transparent';

          // Draw queue number text in dark color
          ctx.fillStyle = '#101010'; // Nearly black to match background
          ctx.font = 'bold 22px sans-serif';
          ctx.textBaseline = 'middle';
          ctx.textAlign = 'center';
          ctx.fillText(queueIndex.toString(), badgeX, badgeY);
          
          // Reset shadow
          ctx.shadowColor = 'transparent';
          ctx.shadowBlur = 0;
        } else {
          ctx.fillStyle = '#121212';
          ctx.fillRect(0, 0, canvasWidth, canvasHeight);

          // Placeholder rectangle if no image
          ctx.fillStyle = '#333';
          ctx.fillRect(imageX, imageY, imageSize, imageSize);
        }

        // Text styles
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 32px sans-serif';
        ctx.textBaseline = 'middle';

        // Move text far right for better visibility
        const textLeftMargin = imageX + imageSize + 120;
        
        // Remove accent line - not present in the image
        
        // Add very subtle card border like in the image
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(5, 5, canvasWidth - 10, canvasHeight - 10, 24); // Match corner radius
        ctx.stroke();
        
        // Song title with enhanced shadow for better visibility
        ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
        ctx.shadowBlur = 6;
        ctx.shadowOffsetX = 2;
        ctx.shadowOffsetY = 2;
        
        // Position title and artist with proper vertical alignment
        const titleY = imageY + 45;
        const artistY = titleY + 35; // Position directly below the title

        // Song title (wrap if too long)
        const maxTitleWidth = canvasWidth - imageSize - 100; // More space for title truncation
        let title = track.info.title;
        if (ctx.measureText(title).width > maxTitleWidth) {
          while (ctx.measureText(title + '...').width > maxTitleWidth && title.length > 0) {
            title = title.slice(0, -1);
          }
          title += '...';
        }
        
        // Remove the black box - no background highlight for clean appearance
        const titleWidth = ctx.measureText(title).width;
        
        // Draw title in white with subtle shadow - smaller font size
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
        ctx.shadowBlur = 4;
        ctx.shadowOffsetX = 1;
        ctx.shadowOffsetY = 1;
        ctx.font = 'bold 32px sans-serif'; // Reduced from 40px
        ctx.fillText(title, textLeftMargin, titleY);
        
        // Artist name in light gray - smaller font size
        ctx.shadowColor = 'rgba(0, 0, 0, 0.4)';
        ctx.shadowBlur = 2;
        ctx.font = '24px sans-serif'; // Reduced from 32px
        ctx.fillStyle = '#cccccc'; // Light gray color for artist name
        ctx.fillText(track.info.author, textLeftMargin, artistY);

        // Footer text (e.g., "Added to queue")
        // Removed as per user request
        // ctx.font = '22px sans-serif';
        // ctx.fillStyle = '#888888';
        // ctx.fillText('Added to queue', imageX + imageSize + 20, imageY + 130);

        const buffer = canvas.toBuffer();

        await interaction.editReply({
          content: `Added to queue: ${track.info.title}`,
          files: [{ attachment: buffer, name: 'now-playing.png' }]
        });
      } else {
        await interaction.editReply('No results found for your query.');
      }
    } catch (error) {
      console.error(error);
      await interaction.editReply('There was an error trying to play the track.');
    }
  }
};
