const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pause')
    .setDescription('Pause the currently playing track'),

  async execute(interaction, client) {
    const player = client.riffy.players.get(interaction.guildId);

    if (!player || !player.playing) {
      return interaction.reply({ content: 'There is no track playing right now.', ephemeral: true });
    }

    try {
      player.pause();
      await interaction.reply('⏸️ Paused the current track.');
    } catch (error) {
      console.error(error);
      await interaction.reply('There was an error trying to pause the track.');
    }
  }
}; 