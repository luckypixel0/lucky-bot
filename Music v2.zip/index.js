require('dotenv').config();
const { Client, GatewayDispatchEvents, GatewayIntentBits, Collection, REST, Routes } = require('discord.js');
const { Riffy } = require('riffy');
const path = require('path');
const fs = require('fs');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
});

// Command collection and command registration array
client.commands = new Collection();
const commands = [];

// Load commands from commands folder
const commandsPath = path.join(__dirname, 'commands');
if (fs.existsSync(commandsPath)) {
  const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
  for (const file of commandFiles) {
    const command = require(path.join(commandsPath, file));
    client.commands.set(command.data.name, command);
    commands.push(command.data.toJSON());
  }
}

const nodes = [
  {
    host: process.env.LAVALINK_HOST || 'localhost',
    password: process.env.LAVALINK_PASSWORD || 'youshallnotpass',
    port: parseInt(process.env.LAVALINK_PORT) || 2333,
    secure: false,
  },
];

client.riffy = new Riffy(client, nodes, {
  send: (payload) => {
    const guild = client.guilds.cache.get(payload.d.guild_id);
    if (guild) guild.shard.send(payload);
  },
  defaultSearchPlatform: 'ytmsearch',
  restVersion: 'v4',
});

client.riffy.on('nodeConnect', (node) => {
  console.log(`Lavalink node "${node.name}" connected.`);
});

client.riffy.on('nodeError', (node, error) => {
  console.log(`Lavalink node "${node.name}" encountered an error: ${error.message}.`);
});

client.on('ready', async () => {
  client.riffy.init(client.user.id);
  console.log(`Logged in as ${client.user.tag}`);
  
  // Register slash commands
  try {
    console.log(`Started refreshing ${commands.length} application (/) commands.`);
    
    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
    
    // The put method is used to fully refresh all commands globally
    const data = await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID),
      { body: commands },
    );
    
    console.log(`Successfully reloaded ${data.length} application (/) commands.`);
  } catch (error) {
    console.error('Error registering slash commands:', error);
  }
});

client.on('raw', (d) => {
  if (![GatewayDispatchEvents.VoiceStateUpdate, GatewayDispatchEvents.VoiceServerUpdate].includes(d.t)) return;
  client.riffy.updateVoiceState(d);
});

client.on('interactionCreate', async function(interaction) {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction, client);
  } catch (error) {
    console.error(error);
    await interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
  }
});

// Handle autocomplete interactions
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isAutocomplete()) return;
  
  const command = client.commands.get(interaction.commandName);
  if (!command || !command.autocomplete) return;

  try {
    await command.autocomplete(interaction);
  } catch (error) {
    console.error(`Error handling autocomplete for ${interaction.commandName}:`, error);
  }
});

// Handle button interactions for help menu
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;
  
  // Help menu button handlers
  if (interaction.customId.startsWith('help_')) {
    const category = interaction.customId.replace('help_', '');
    const helpCommand = client.commands.get('help');
    
    if (!helpCommand) return;
    
    try {
      const commands = [...client.commands.values()];
      const { EmbedBuilder } = require('discord.js');
      
      // Define categories and their commands
      const categories = {
        'player_controls': {
          name: 'Player Controls',
          commands: ['play', 'pause', 'resume', 'skip', 'stop', 'seek', 'volume']
        },
        'queue': {
          name: 'Queue Management',
          commands: ['queue', 'nowplaying', 'loop', 'shuffle', 'playlist']
        },
        'utility': {
          name: 'Utility',
          commands: ['help']
        }
      };
      
      const selectedCategory = categories[category];
      
      if (selectedCategory) {
        const embed = new EmbedBuilder()
          .setColor('#1DB954')
          .setTitle(`${selectedCategory.name} Commands`)
          .setDescription('Detailed command information for this category:');
        
        // Get commands from the selected category
        const categoryCommands = selectedCategory.commands
          .filter(name => client.commands.has(name))
          .map(name => {
            const cmd = client.commands.get(name);
            return `\`/${cmd.data.name}\` - ${cmd.data.description}`;
          })
          .join('\n\n');
        
        if (categoryCommands) {
          embed.addFields({ name: 'Available Commands', value: categoryCommands });
        } else {
          embed.addFields({ name: 'Available Commands', value: 'No commands available in this category.' });
        }
        
        await interaction.reply({
          embeds: [embed],
          ephemeral: true
        });
      }
    } catch (error) {
      console.error('Error handling help button interaction:', error);
      await interaction.reply({
        content: 'There was an error displaying the help information.',
        ephemeral: true
      });
    }
  }
});

client.login(process.env.DISCORD_TOKEN);
