from __future__ import annotations

from discord.ext import commands, tasks
import discord
import aiohttp
import asyncio
import typing
from typing import List
import aiosqlite
from utils.config import OWNER_IDS
from utils import getConfig, updateConfig
from .Context import Context
from colorama import Fore, Style, init
import os

init(autoreset=True)

extensions: List[str] = ["cogs"]


class Lucky(commands.AutoShardedBot):
    def __init__(self, *args, **kwargs):
        intents = discord.Intents.all()
        intents.presences = True
        intents.members = True

        super().__init__(
            command_prefix=self.get_prefix,
            case_insensitive=True,
            intents=intents,
            status=discord.Status.do_not_disturb,
            strip_after_prefix=True,
            owner_ids=OWNER_IDS,
            allowed_mentions=discord.AllowedMentions(
                everyone=False, replied_user=False, roles=False
            ),
            sync_commands_debug=True,
            sync_commands=True,
            shard_count=1,
        )
        self.status_index = 0
        self.status_list = []

    async def setup_hook(self):
        await self.load_extensions()
        self.status_task.start()

    async def load_extensions(self):
        for extension in extensions:
            try:
                await self.load_extension(extension)
                print(Fore.GREEN + Style.BRIGHT + f"[Lucky] Loaded: {extension}")
            except Exception as e:
                print(Fore.RED + Style.BRIGHT + f"[Lucky] Failed to load {extension}: {e}")
        print(Fore.GREEN + Style.BRIGHT + "=" * 40)

    @tasks.loop(seconds=30)
    async def status_task(self):
        await self.wait_until_ready()
        if not self.guilds:
            return

        guild = self.guilds[0]
        try:
            config = await getConfig(guild.id)
            prefix = config.get("prefix", ">")
        except Exception:
            prefix = ">"

        user_count = sum(g.member_count or 0 for g in self.guilds)
        guild_count = len(self.guilds)

        self.status_list = [
            (discord.ActivityType.playing, f"{prefix}help | lucky.gg"),
            (discord.ActivityType.watching, f"{user_count} users"),
            (discord.ActivityType.watching, f"{guild_count} servers"),
            (discord.ActivityType.listening, "Protecting your server"),
            (discord.ActivityType.playing, "Lucky Bot 🍀"),
        ]

        current = self.status_list[self.status_index % len(self.status_list)]
        await self.change_presence(
            activity=discord.Activity(type=current[0], name=current[1])
        )
        self.status_index += 1

    async def send_raw(self, channel_id: int, content: str, **kwargs) -> typing.Optional[discord.Message]:
        await self.http.send_message(channel_id, content, **kwargs)

    async def invoke_help_command(self, ctx: Context) -> None:
        return await ctx.send_help(ctx.command)

    async def fetch_message_by_channel(
        self, channel: discord.TextChannel, message_id: int
    ) -> typing.Optional[discord.Message]:
        async for msg in channel.history(
            limit=1,
            before=discord.Object(message_id + 1),
            after=discord.Object(message_id - 1),
        ):
            return msg

    async def get_prefix(self, message: discord.Message):
        if message.guild:
            guild_id = message.guild.id
            async with aiosqlite.connect("db/np.db") as db:
                async with db.execute(
                    "SELECT id FROM np WHERE id = ?", (message.author.id,)
                ) as cursor:
                    row = await cursor.fetchone()
            data = await getConfig(guild_id)
            prefix = data["prefix"]
            if row:
                return commands.when_mentioned_or(prefix, "")(self, message)
            return commands.when_mentioned_or(prefix)(self, message)
        else:
            async with aiosqlite.connect("db/np.db") as db:
                async with db.execute(
                    "SELECT id FROM np WHERE id = ?", (message.author.id,)
                ) as cursor:
                    row = await cursor.fetchone()
            if row:
                return commands.when_mentioned_or("?", "")(self, message)
            return commands.when_mentioned_or("")(self, message)

    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        if before.content == after.content:
            return
        if after.guild is None or after.author.bot:
            return
        ctx: Context = await self.get_context(after, cls=Context)
        if ctx.command is None:
            return
        await self.invoke(ctx)


def setup_bot():
    intents = discord.Intents.all()
    return Lucky(intents=intents)

# Lucky Bot — Rewritten
